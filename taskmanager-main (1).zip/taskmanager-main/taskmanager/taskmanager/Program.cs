﻿using taskmanager;

class Program
{
    public static void Main(string[] args)
    {
        TaskManager taskManager = new TaskManager();
        taskManager.Run();
    }
}
